This dataset was created for the Size-Inclusive Sewing Database. The information in the Size-Inclusive Sewing database is being collected for educational purposes. The curators, Carmen Paul and Kat Fritz, are graduate students at the University of Washington's iSchool, working under instructor Nic Weber.

The Size-Inclusive Sewing database is curated by Carmen Paul and Kat Fritz. Users can submit information about sewing patterns via Google Forms. Users can submit as many patterns as they'd like; submissions are reviewed before publication.

The most important criterion for inclusion in this database is the maximum size range included in the sewing patterns. The size range must include at least a 60" chest or 60" hip measurement. Body and/or finished garment measurements may be included; finished garment measurements must account for ease to qualify.

Information about sewing patterns outside the minimum size range indicated will not be included. Other patterns, such as knitting or crochet patterns, are not currently accepted.
